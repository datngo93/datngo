/*
 * main.c
 *
 * Created: 5/11/2024 3:37:12 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
	unsigned char button;

	DDRG = 0xFF; PORTG = 0x02;
	DDRB = 0xFF; PORTB = 0x00;
	DDRF = 0x00;

	OCR0 = 0x7F;
	TCNT0 = 0x00;
	TCCR0 = 0x6F;

    while(1)
    {
        button = PINF & 0x03;
		switch (button) {
			case 0x01:
				if (OCR0 < 246) OCR0 += 1;
				break;
			case 0x02:
				if (OCR0 > 9) OCR0 -= 1;
				break;
			default: break;
		} 
		_delay_ms(50);
    }
}