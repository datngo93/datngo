/*
 * main.c
 *
 * Created: 5/11/2024 3:11:04 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
	char cmd = 0;
	DDRB = 0xFF;
	DDRD = 0x00;

    while(1)
    {
		cmd = PIND & 0x0F;
		switch (cmd) {
			case 0x00: PORTB = 0x00; break;
			case 0x01: PORTB = 0x09; break;
			case 0x02: PORTB = 0x06; break;
			case 0x04: PORTB = 0x01; break;
			case 0x08: PORTB = 0x08; break;
			default: PORTB = 0x00; break;
		} 
		_delay_ms(50);
    }
}