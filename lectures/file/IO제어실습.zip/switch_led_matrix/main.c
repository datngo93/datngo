/*
 * main.c
 *
 * Created: 3/13/2024 9:07:13 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>

#define DELAY_TIME 1000
#define cbi(REG8, BITNUM) REG8&=~(_BV(BITNUM))
#define sbi(REG8, BITNUM) REG8|=(_BV(BITNUM))

void getKeyNo(unsigned char);
void number(unsigned char);
void delay(int);

int main(void)
{
   unsigned char outE = 0x01;
   DDRB = 0xff; PORTB = 0xf0;
   DDRE = 0x0f; PORTE = outE;
   while(1)
   {
      getKeyNo(outE);
      outE = outE<<1;
      if (outE==0x10) outE = 0x01;
      PORTE = outE;
   }
}

void getKeyNo(unsigned char outE) {
   char poE, a, b, no=0;
   poE = PINE;
   poE ^= outE;
   poE >>= 4;
   if (poE) {
      a = poE>>1; // divide by 2
      if (a>3) a = 3;
      b = outE>>1;
      if (b>3) b = 3;
      no = (a<<2)+b; // a*4+b
      number(no);
   }
}

void number(unsigned char no) {
   sbi(PORTB, no%4);
   cbi(PORTB, (no>>2)+4); // no/4+4
   delay(DELAY_TIME);
   cbi(PORTB, no%4);
   sbi(PORTB, (no>>2)+4);
}

void delay(int d) {
   int i;
   for (i=0; i<d; i++) _delay_ms(1);
}