/*
 * main.c
 *
 * Created: 3/12/2024 3:43:49 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>

#define DELAY_TIME 500

void delay(int);

int main(void)
{
   unsigned char mask=0x01;
   DDRB = 0xff; // PORTB 출력 모드
   while(1)
   {
      if (mask==0x00) mask = 0x01;
      PORTB = 0xff^mask;
      delay(DELAY_TIME);
      mask = mask<<1;
   }
}

void delay(int d) {
   int i;
   for (i=0; i<d; i++) _delay_ms(1);
}