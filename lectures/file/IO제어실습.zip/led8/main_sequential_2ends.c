/*
 * main.c
 *
 * Created: 3/12/2024 3:43:49 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>

#define DELAY_TIME 500

void delay(int);

int main(void)
{
   unsigned char mask1=0x01, mask2=0x80, dir=0;
   DDRB = 0xff; // PORTB 출력 모드
   while(1)
   {
      PORTB = 0xff^(mask1|mask2);
      delay(DELAY_TIME);
      if (dir==0) {
         mask1 = mask1<<1;
         mask2 = mask2>>1;
         if (mask1==0x10) {
            mask1 = 0x04;
            mask2 = 0x20;
            dir = 1;
         }
      } else {
         mask1 = mask1>>1;
         mask2 = mask2<<1;
         if (mask1==0x00) {
            mask1 = 0x02;
            mask2 = 0x40;
            dir = 0;
         }
      }
   }
}

void delay(int d) {
	int i;
	for (i=0; i<d; i++) _delay_ms(1);
}