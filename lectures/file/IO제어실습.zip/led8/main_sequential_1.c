/*
 * main.c
 *
 * Created: 3/12/2024 3:43:49 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>

#define DELAY_TIME 1000

void delay(int);

int main(void)
{
   DDRB = 0xff; // PORTB 출력 모드
   while(1)
   {
      PORTB = 0xfe; delay(DELAY_TIME); // 1st LED on and delay
      PORTB = 0xfd; delay(DELAY_TIME); // 2nd LED on and delay
      PORTB = 0xfb; delay(DELAY_TIME); // 3rd LED on and delay
      PORTB = 0xf7; delay(DELAY_TIME); // 4th LED on and delay
      PORTB = 0xef; delay(DELAY_TIME); // 5th LED on and delay
      PORTB = 0xdf; delay(DELAY_TIME); // 6th LED on and delay
      PORTB = 0xbf; delay(DELAY_TIME); // 7th LED on and delay
      PORTB = 0x7f; delay(DELAY_TIME); // 8th LED on and delay
   }
}

void delay(int d) {
   int i;
   for (i=0; i<d; i++) _delay_ms(1);
}