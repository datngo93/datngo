/*
 * main.c
 *
 * Created: 3/12/2024 3:43:49 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>

#define DELAY_TIME 500

void delay(int);

int main(void)
{
	unsigned int mask1=0x0001, mask2=0x8000;
	unsigned char dir=0;
	DDRA = 0xff; // PORTA ?? ??
	DDRB = 0xff; // PORTB ?? ??
    while(1)
    {
		PORTA = 0xffff^(mask1|mask2);
		PORTB = (0xffff^(mask1|mask2))>>8;
		delay(DELAY_TIME);
		if (dir==0) {
			mask1 = mask1<<1;
			mask2 = mask2>>1;
			if (mask1==0x0100) {
				mask1 = 0x0040;
				mask2 = 0x0200;
				dir = 1;
			}
		} else {
			mask1 = mask1>>1;
			mask2 = mask2<<1;
			if (mask1==0x0000) {
				mask1 = 0x0002;
				mask2 = 0x4000;
				dir = 0;
			}
		}
    }
}

void delay(int d) {
	int i;
	for (i=0; i<d; i++) _delay_ms(1);
}