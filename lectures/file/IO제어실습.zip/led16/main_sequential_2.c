/*
 * main.c
 *
 * Created: 3/12/2024 3:43:49 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <avr/delay.h>

#define DELAY_TIME 500

void delay(int);

int main(void)
{
   unsigned int mask=0x0001;
   DDRA = 0xff; // PORTA 출력 모드
   DDRB = 0xff; // PORTB 출력 모드
   while(1)
   {
      if (mask==0x0000) mask = 0x0001;
      PORTA = 0xffff^mask;
      PORTB = (0xffff^mask)>>8;
      delay(DELAY_TIME);
      mask = mask<<1;
   }
}

void delay(int d) {
   int i;
   for (i=0; i<d; i++) _delay_ms(1);
}