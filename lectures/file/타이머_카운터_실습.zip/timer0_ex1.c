/*
 * main.c
 *
 * Created: 4/2/2024 11:15:32 AM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <avr/interrupt.h>

typedef unsigned char byte;
typedef unsigned int  word;

#define cbi(REG8, BITNUM) REG8 &= ~(_BV(BITNUM))
#define sbi(REG8, BITNUM) REG8 |= _BV(BITNUM)

byte led=0x01, ledB=0x01;

// Timer 0 ISR
ISR(TIMER0_OVF_vect) {
	if (led>10) {
		led = 1;
		PORTB = ledB;
		ledB <<= 1;
		if (ledB==0x00) ledB = 0x01;
	}
	else led++;
}

int main(void)
{
	DDRB = 0xff;
	PORTB = ledB;

	TCCR0 = 0x07;
	sbi(TIMSK, 0);
	sei(); // SREG |= 0x80;
	TCNT0 = 0x00;

    while(1)
    {
        //TODO:: Please write your application code 
    }
}