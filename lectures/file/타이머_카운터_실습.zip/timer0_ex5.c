/*
 * main.c
 *
 * Created: 4/3/2024 2:57:36 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <avr/interrupt.h>

typedef unsigned char byte;
typedef unsigned int  word;

#define cbi(REG8, BITNUM) REG8 &= ~(_BV(BITNUM))
#define sbi(REG8, BITNUM) REG8 |= _BV(BITNUM)

byte led=1, ledE=0x01;

ISR(TIMER0_OVF_vect) {
	if (led>10) {
		led = 0;
		PORTE = ledE;
		ledE <<= 1;
		if (ledE==0x00) ledE = 0x01;
	}
	else led++;
}

ISR(TIMER0_COMP_vect) {
	OCR0 -= 1;
	if (OCR0<0x1f) OCR0 = 0xff;
}

int main(void)
{
	DDRE = 0xff;
	DDRB = 0xff;
	PORTE = ledE;

	sbi(TIMSK, 0);
	sbi(TIMSK, 1);
	TCCR0 = 0x6f;
	OCR0 = 0x7f;
	TCNT0 = 0x00;
	sei();

    while(1)
    {
        //TODO:: Please write your application code 
    }
}