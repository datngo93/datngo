/*
 * main.c
 *
 * Created: 4/3/2024 1:48:18 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <avr/interrupt.h>

typedef unsigned char byte;
typedef unsigned int  word;

#define cbi(REG8, BITNUM) REG8 &= ~(_BV(BITNUM))
#define sbi(REG8, BITNUM) REG8 |= _BV(BITNUM)

byte ledE = 0x01;

int main(void)
{
	DDRE = 0xff;
	DDRB = 0xff;
	PORTE = ledE;

	TCCR0 = 0x1f;
	OCR0 = 0x80;
	TCNT0 = 0x00;

    while(1)
    {
        //TODO:: Please write your application code 
    }
}