/*
 * main.c
 *
 * Created: 3/26/2024 10:20:39 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>

unsigned char act[4] = {0xe0, 0xd0, 0xb0, 0x70};

int main(void)
{
   DDRF = 0xff;
   int i, j=0, r=0;
   while(1) {
      for (i=0; i<4; i++) {
         if (i==0) PORTF = (j/1000)|act[i];
         if (i==1) PORTF = ((j%1000)/100)|act[i];
         if (i==2) PORTF = ((j%100)/10)|act[i];
         if (i==3) PORTF = (j%10)|act[i];
         _delay_ms(1);
      }
      r++;
      if (r==20) { // update j every 20*20 = 400ms
         r=0;
         j++;
      }
      if (j>9999) j=0;
      _delay_ms(16); // total delay time is 1*4 + 16 = 20ms
   }
}