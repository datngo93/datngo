/*
 * main.c
 *
 * Created: 3/26/2024 10:05:14 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
   int i = 0;
   DDRF = 0xff;
   while(1)
   {
      PORTF = i;
      _delay_ms(500);
      i++;
      if (i>9) i = 0;
   }
}