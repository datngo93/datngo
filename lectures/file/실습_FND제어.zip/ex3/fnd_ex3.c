/*
 * main.c
 *
 * Created: 3/19/2024 9:58:55 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>

unsigned char CC[] = {0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x27, 0x7f, 0x67, 0x77, 0x7c, 0x58, 0x5e, 0x79, 0x71, 0x80};
unsigned char CA[] = {0xc0, 0xf9, 0xa4, 0xb0, 0x99, 0x92, 0x82, 0xd8, 0x80, 0x98, 0x88, 0x83, 0xa7, 0xa1, 0x86, 0x8e, 0x7f};

unsigned char act[4] = {0x0e, 0x0d, 0x0b, 0x07};

int main(void)
{
   DDRB = DDRF = 0xff;
   int i, j=0, r=0;
   while(1) {
      for (i=0; i<4; i++) {
         PORTF = act[i];
         if (i==0) PORTB = CC[j/1000];
         if (i==1) PORTB = CC[(j%1000)/100];
         if (i==2) PORTB = CC[(j%100)/10];
         if (i==3) PORTB = CC[j%10];
         _delay_ms(1);
      }
      r++;
      if (r==20) { // update j every 20*20 = 400ms
         r=0;
         j++;
      }
      if (j>9999) j=0;
      _delay_ms(16); // total delay time is 1*4 + 16 = 20ms
   }
}