/*
 * main.c
 *
 * Created: 3/19/2024 9:58:55 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>

void display(void);
void time_process(void);

unsigned char CC[] = {0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x27, 0x7f, 0x67, 0x77, 0x7c, 0x58, 0x5e, 0x79, 0x71, 0x80};
unsigned char CA[] = {0xc0, 0xf9, 0xa4, 0xb0, 0x99, 0x92, 0x82, 0xd8, 0x80, 0x98, 0x88, 0x83, 0xa7, 0xa1, 0x86, 0x8e, 0x7f};

unsigned char h, m, s;

int main(void)
{
   DDRA = DDRB = DDRC = DDRD = DDRE = DDRF = 0xff;
   h = m = s = 0;
   while(1)
   {
      display();
      _delay_ms(1000);
      time_process();
   }
}

void display(void) {
   PORTA = CC[h/10]; PORTB = CC[h%10];
   PORTC = CC[m/10]; PORTD = CC[m%10];
   PORTE = CC[s/10]; PORTF = CC[s%10];
}

void time_process(void) {
   s++;
   if (s>59) {
      s = 0;
      m++;
      if (m>59) {
         m = 0;
         h++;
         if (h>12) h = 1;
      }
   }
}