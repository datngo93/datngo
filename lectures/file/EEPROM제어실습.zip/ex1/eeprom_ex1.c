/*
 * main.c
 *
 * Created: 3/21/2024 5:23:49 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "stdio.h"
#include "lcd4.h"

void EEPROM_write(unsigned int, unsigned char);
unsigned char EEPROM_read(unsigned int);
char check_EEPROM();
void set_EEPROM();

int main(void)
{
	unsigned int addr_EEPROM = 0x0002;
	unsigned char data_EEPROM, interruptNo = 0;
	char msg[20];

	DDRF = 0xff; // LCD ?? ??
	DDRE = 0x00; // PORTE ?? ??
	PORTE = 0xff; // PORTE 1? ??

	EIMSK = 0x10; // ???? 4 ??
	EICRB = 0xd2; // falling edge ??
	init_lcd4();

	if (check_EEPROM()) data_EEPROM = EEPROM_read(addr_EEPROM);
	else {
		set_EEPROM();
		data_EEPROM = 0;
	}
	sprintf(msg, "Current row: %d", data_EEPROM);
	writeString_lcd4(0, 0, msg);
	delay(1);
	writeString_lcd4(0, 1, "Program restart");

    while(1)
    {
        interruptNo = EIFR;
		if (interruptNo==0x10) {
			interruptNo = 4;
			EIFR |= 0x10;
			data_EEPROM++;
			EEPROM_write(0x0002, data_EEPROM);
			sprintf(msg, "Current row: %d", data_EEPROM);
			writeString_lcd4(0, 0, msg);
			sprintf(msg, "%d checked      ", interruptNo);
			interruptNo = 0;
			writeString_lcd4(0, 1, msg);
		}
    }
}

char check_EEPROM() {
	char data0, data1;
	data0 = EEPROM_read(0x0000);
	delay(1);
	data1 = EEPROM_read(0x0001);
	if (data0=='1' && data1=='2') return 1;
	else return 0;
}

void set_EEPROM() {
	EEPROM_write(0x0000, '1'); delay(1);
	EEPROM_write(0x0001, '2'); delay(1);
	EEPROM_write(0x0002, 0x00);
}

void EEPROM_write(unsigned int addr, unsigned char data) {
	while (EECR & (1<<EEWE)); // ??? ??? ?????? ????
	EEAR = addr;
	EEDR = data;
	EECR |= (1<<EEMWE); // EEMWE = 1
	EECR |= (1<<EEWE);  // EEWE = 1? ?? EEPROM? ??
}

unsigned char EEPROM_read(unsigned int addr) {
	while (EECR & (1<<EEWE));
	EEAR = addr;
	EECR |= (1<<EERE); // EERE = 1? ?? ???? ?? EEDR? ????
	return EEDR;
}