/*
 * main.c
 *
 * Created: 3/21/2024 6:11:34 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "stdio.h"
#include "string.h"
#include "lcd4.h"

void EEPROM_write(unsigned int, unsigned char);
unsigned char EEPROM_read(unsigned int);

char *addr, *pData;

ISR(EE_READY_vect) {
	if (*pData) EEPROM_write((unsigned int)addr++, *pData++);
	else EECR &= 0xf7;
}

int main(void)
{
	char noMsg, msg[] = "Welcome";

	DDRF = 0xff;
	init_lcd4();

	pData = msg;
	addr = 0x0000;
	noMsg = sizeof(msg);

	SREG |= 0x80;
	EECR |= (1<<EERIE);

	while (EECR & (1<<EEWE));
	strcpy(msg, "Goodbye");
	addr = 0x0000;
	while (EECR & (1<<EEWE));
	for (int i=0; i<noMsg; i++)
		msg[i] = EEPROM_read((unsigned int)addr++);
	writeString_lcd4(0, 1, msg);

    while(1);
}

void EEPROM_write(unsigned int addr, unsigned char data) {
	while (EECR & (1<<EEWE));
	EEAR = addr;
	EEDR = data;
	EECR |= (1<<EEMWE);
	EECR |= (1<<EEWE);
}

unsigned char EEPROM_read(unsigned int addr) {
	while (EECR & (1<<EEWE));
	EEAR = addr;
	EECR |= (1<<EERE);
	return EEDR;
}