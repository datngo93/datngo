/*
 * main.c
 *
 * Created: 3/26/2024 10:05:14 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>

#define DELAY_TIME 500

void delay(int);

int main(void)
{
	int i = 0;
	DDRF = 0xff;
    while(1)
    {
        PORTF = i;
		delay(DELAY_TIME);
		i++;
		if (i>9) i = 0;
    }
}

void delay(int d) {
	int i;
	for (i=0; i<d; i++) _delay_ms(1);
}