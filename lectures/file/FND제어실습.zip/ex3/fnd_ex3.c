/*
 * main.c
 *
 * Created: 3/19/2024 9:58:55 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>

#define TRUE 1
#define FALSE 0
#define DELAY_TIME 2000

void delay(int);

unsigned char CC[] = {0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x27, 0x7f, 0x67, 0x77, 0x7c, 0x58, 0x5e, 0x79, 0x71, 0x80};
unsigned char CA[] = {0xc0, 0xf9, 0xa4, 0xb0, 0x99, 0x92, 0x82, 0xd8, 0x80, 0x98, 0x88, 0x83, 0xa7, 0xa1, 0x86, 0x8e, 0x7f};

unsigned char act[4] = {0xef, 0xdf, 0xbf, 0x7f};

int main(void)
{
	DDRB = DDRF = 0xff;
	int i, j;
	unsigned char seq = TRUE;
    while(1)
    {
		if (seq) {
			for (i=0; i<4; i++) {
				for (j=0; j<16; j++) {
					PORTF = act[i];
					PORTB = CC[j]|0x80;
					delay(DELAY_TIME);
				}
			}
		} else {
			for (i=0; i<16; i++) {
				for (j=0; j<4; j++) {
					PORTF = act[j];
					PORTB = CC[i]|0x80;
					_delay_ms(50);
				}
				delay(DELAY_TIME);
			}
		}
    }
}

void delay(int d) {
	int i;
	for (i=0; i<d; i++) _delay_ms(1);
}