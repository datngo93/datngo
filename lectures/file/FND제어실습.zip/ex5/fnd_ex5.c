/*
 * main.c
 *
 * Created: 3/26/2024 10:20:39 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>

#define TRUE 1
#define FALSE 0
#define DELAY_TIME 500

void delay(int);

unsigned char act[4] = {0xef, 0xdf, 0xbf, 0x7f};

int main(void)
{
	int i, j;
	unsigned char seq = FALSE;
	DDRF = 0xff;
    while(1)
    {
         if (seq) {
			for (i=0; i<4; i++) {
				for (j=0; j<10; j++) {
					PORTF = (j&0x0f) | (act[i]&0xf0);
					delay(DELAY_TIME);
				}
			}
		 } else {
			for (i=0; i<10; i++) {
				for (j=0; j<4; j++) {
					PORTF = (i&0x0f) | (act[j]&0xf0);
					delay(DELAY_TIME);
				}
			}
		 }
    }
}

void delay(int d) {
	int i;
	for (i=0; i<d; i++) _delay_ms(1);
}