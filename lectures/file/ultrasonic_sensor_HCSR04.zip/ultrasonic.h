﻿/*
 * ultrasonic.h
 *
 * Created: 2025-05-25 오후 8:59:59
 *  Author: USER
 */ 


#ifndef ULTRASONIC_H_
#define ULTRASONIC_H_

#define US_PORT PORTF
#define US_PIN PINF
#define US_DDR DDRF

#define US_TRIG_POS PF2 // trigger pin is connected to port F pin 2
#define US_ECHO_POS PF3 // echo pin is connected to port F pin 3

#define US_ERROR -1
#define US_NO_OBSTACLE -2

void US_init() {
	US_DDR |= (1<<US_TRIG_POS);
}

void US_trigger() {
	US_PORT |= (1<<US_TRIG_POS);
	_delay_us(15);
	US_PORT &= ~(1<<US_TRIG_POS);
}

uint16_t US_getPulseWidth() {
	uint32_t i, result;
	
	// check the echo pin for certain amount of time
	// if there is no signal -> sensor is not working
	for (i=0; i<600000; i++) {
		if (!(US_PIN & (1<<US_ECHO_POS)))
			continue; // still waiting
		else
			break; // rising edge detected, break
	}
	
	if (i==600000) return US_ERROR; // timed out
	
	// use timer to detect the pulse width
	TCCR1A = 0x00;
	TCCR1B = (1<<CS11);
	TCNT1 = 0x00; // start timer
	
	for (i=0; i<600000; i++) {
		if (US_PIN & (1<<US_ECHO_POS)) {
			// if timer exceeds 60000 -> no object in the range of the sensor
			if (TCNT1 > 60000) break;
			else continue;
		} else break;
	}
	
	if (i==600000) return US_NO_OBSTACLE;
	
	result = TCNT1;
	TCCR1B = 0x00; // stop timer
	
	if (result > 60000) return US_NO_OBSTACLE;
	else return result;
}

#endif /* ULTRASONIC_H_ */