/*
 * main.c
 *
 * Created: 3/21/2024 12:03:27 AM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "lcd4.h"
#include "stdio.h"

int main(void)
{
	unsigned char interruptNo = 0;
	char msg[20];
	DDRF = 0xff;
	DDRE = 0x00;  // ?? ??
	PORTE = 0xff; // ?? ?? 1? ??

	//SREG |= 0x80; // 7?? ?? 1? ???
	EIMSK = 0xf0; // ???? 4, 5, 6, 7? ??
	EICRB = 0xaa; // falling edge? 10 ??? 1010_1010? ??

	init_lcd4();

	writeString_lcd4(0, 0, "Interrupt No: ");

    while(1)
    {
		interruptNo = EIFR;
		if (interruptNo) {
			switch (interruptNo) {
                case 0x10:
                    interruptNo = 4;
                    EIFR |= 0x10;
                    break;
                case 0x20:
                    interruptNo = 5;
                    EIFR |= 0x20;
                    break;
                case 0x40:
                    interruptNo = 6;
                    EIFR |= 0x40;
                    break;
                case 0x80:
                    interruptNo = 7;
                    EIFR |= 0x80;
                    break;
            }
            sprintf(msg, "%d checked", interruptNo);
            interruptNo = 0;
            writeString_lcd4(0, 1, msg);
		}
    }
}