/*
 * main.c
 *
 * Created: 3/21/2024 12:03:27 AM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "lcd4.h"
#include "stdio.h"

volatile unsigned char interruptNo = 0;

ISR(INT4_vect) {
	interruptNo = 4;
}

ISR(INT5_vect) {
	interruptNo = 5;
}

ISR(INT6_vect) {
	interruptNo = 6;
}

ISR(INT7_vect) {
	interruptNo = 7;
}

int main(void)
{
	char msg[20];
	DDRF = 0xff;
	DDRE = 0x00;  // ?? ??
	PORTE = 0xff; // ?? ?? 1? ??

	SREG |= 0x80; // 7?? ?? 1? ???
	EIMSK = 0xf0; // ???? 4, 5, 6, 7? ??
	EICRB = 0xaa; // falling edge? 10 ??? 1010_1010? ??

	init_lcd4();

	writeString_lcd4(0, 0, "Interrupt No: ");

    while(1)
    {
        if (interruptNo) {
			sprintf(msg, "%d checked", interruptNo);
			interruptNo = 0;
			writeString_lcd4(0, 1, msg);
		}
    }
}