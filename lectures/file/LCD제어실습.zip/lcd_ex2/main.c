/*
 * main.c
 *
 * Created: 3/20/2024 5:17:16 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>
#include "lcd4.h"

int main(void)
{
	DDRF = 0xff;
	init_lcd4();
	writeString_lcd4(0, 0, "Welcome");
	writeString_lcd4(0, 1, "Have a nice day");
    while(1)
    {
        //TODO:: Please write your application code 
    }
}