/*
 * main.c
 *
 * Created: 5/4/2024 5:10:27 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include "lcd4.h"

long result;
int v;
char msg[20];

ISR(ADC_vect) {
	result = ADC;
	result = result*5000/1023;
	v = result;
	sprintf(msg, "val: %d.%04dv", v/10000, v%10000);
	writeString_lcd4(0, 1, msg);
}

int main(void)
{
	DDRB = 0xFF; // LCD control
	DDRF = 0x00; // ADC input

	init_lcd4();
	writeString_lcd4(0, 0, "ADC 01001 Mode");

	ADCSRA = (1<<ADEN) | (1<<ADIE) | (1<<ADPS2) | (1<<ADPS1);
	ADMUX = 0x09;
	sei();

    while(1)
    {
        ADCSRA |= (1<<ADSC);
		_delay_ms(300);
    }
}