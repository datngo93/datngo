/*
 * main.c
 *
 * Created: 5/4/2024 3:42:36 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include "lcd4.h"

int main(void)
{
	long result;
	int v;
	char msg[20];

	DDRB = 0xFF; // LCD control
	DDRF = 0x00; PORTF = 0x00; // ADC

	init_lcd4();
	writeString_lcd4(0, 0, "Single Mode");

	ADCSRA = (1<<ADEN) | (1<<ADPS2) | (1<<ADPS1) | (1<<ADPS0); // ADC enable, prescaler /128, single conversion
	ADMUX = 0x04;

    while(1)
    {
        ADCSRA |= (1<<ADSC); // trigger ADC conversion
		_delay_ms(1);
		result = ADC;
		result = result*5000/1023;
		v = result;
		sprintf(msg, "val: %d.%03dv", v/1000, v%1000);
		writeString_lcd4(0, 1, msg);
		_delay_ms(500);
    }
}