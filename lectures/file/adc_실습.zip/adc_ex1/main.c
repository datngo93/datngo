/*
 * main.c
 *
 * Created: 5/4/2024 3:16:44 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include "lcd4.h"

int main(void)
{
	char msg[20];
	long result;
	int v;

	DDRB = 0xFF; // LCD control
	DDRF = 0x00; PORTF = 0x00; // input mode

	init_lcd4(); _delay_ms(10);
	writeString_lcd4(0, 0, "Input voltage:");

	ADCSRA = 0xE6; // ADC enable, ADC conversion, free running, prescaler /64
	ADMUX = 0x00; // ADC0, AREF VCC

    while(1)
    {
        result = ADC;
		result = result*5000/1023;
		v = result;
		sprintf(msg, "val: %d.%03dv", v/1000, v%1000);
		writeString_lcd4(0, 1, msg);
		_delay_ms(500); 
    }
}