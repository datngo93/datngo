/*
 * main.c
 *
 * Created: 5/4/2024 4:35:07 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include "lcd4.h"

int main(void)
{
	long result;
	int v;
	char msg[20];

	DDRB = 0xFF; // LCD control
	DDRF = 0x00; PORTF = 0x00; // ADC input

	init_lcd4();
	writeString_lcd4(0, 0, "Free IntFlag Mode");

	ADCSRA = (1<<ADEN) | (1<<ADSC) | (1<<ADFR) | (1<<ADPS2) | (1<<ADPS1); // ADC enable, ADC conversion, free running, prescaler /128
	ADMUX = 0x07;

    while(1)
    {
        ADCSRA |= (1<<ADIF);
		while ((ADCSRA & (1<<ADIF))==0x00) {
			result = ADC;
			result = result*5000/1023;
			v = result;
			sprintf(msg, "val: %d.%03dv", v/1000, v%1000);
			writeString_lcd4(0, 1, msg);
			_delay_ms(500);
		}
    }
}