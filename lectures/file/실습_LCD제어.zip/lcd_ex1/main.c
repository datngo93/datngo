/*
 * main.c
 *
 * Created: 3/20/2024 4:23:26 PM
 *  Author: DatNgo
 */ 

#include <xc.h>
#include <util/delay.h>
#include <avr/io.h>
#include "lcd1.h"

int main(void)
{
   DDRE = DDRB = 0xff;
   init_lcd();
   writeString_lcd(0, 0, "Welcome");
   writeString_lcd(0, 1, "Have a nice day");
   while(1);
}