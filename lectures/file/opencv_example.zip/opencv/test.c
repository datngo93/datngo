#include <stdio.h>
#include <opencv/cv.h>
#include <opencv/highgui.h>

int main() {
   CvCapture *capture = cvCaptureFromCAM(0); // capture default camera
   if (!capture) {
      fprintf(stderr, "Error: Cannot open webcam\n");
      return -1;
   }
   
   cvNamedWindow("Webcam", CV_WINDOW_AUTOSIZE);
   
   while (1) {
      IplImage *frame = cvQueryFrame(capture);
      if (!frame) break;
      
      // manual resizing
      int factor = 2; // power of 2
      int w = frame->width;
      int h = frame->height;
      int c = frame->nChannels;
      
      IplImage *small = cvCreateImage(cvSize(w/factor, h/factor), frame->depth, c);
      unsigned char *src = (unsigned char*)frame->imageData;
      unsigned char *dst = (unsigned char*)small->imageData;
      
      int src_step = frame->widthStep;
      int dst_step = small->widthStep;
      
      int x, y, k;
      for (y=0; y<h/factor; y++) {
         for (x=0; x<w/factor; x++) {
            unsigned char *p_src = src+(factor*y)*src_step+(factor*x)*c;
            unsigned char *p_dst = dst+y*dst_step+x*c;
            for (k=0; k<c; k++) {
               p_dst[k] = p_src[k];
            }
         }
      }
      
      cvShowImage("Webcam", small);
      
      char input = (char)cvWaitKey(30);
      if (input==27) break;
   }
   
   cvReleaseCapture(&capture);
   cvDestroyWindow("Webcam");
   
   return 0;
}