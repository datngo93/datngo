#include <stdio.h>
#include <opencv/cv.h>
#include <opencv/highgui.h>

// =====================
// Resize by half
// =====================
IplImage* resize_half(IplImage *src) {
    int w = src->width;
    int h = src->height;
    int c = src->nChannels;

    IplImage *dst = cvCreateImage(cvSize(w/2, h/2), src->depth, c);

    unsigned char *pSrc = (unsigned char*) src->imageData;
    unsigned char *pDst = (unsigned char*) dst->imageData;

    int src_step = src->widthStep;
    int dst_step = dst->widthStep;

    for (int y = 0; y < h/2; y++) {
        for (int x = 0; x < w/2; x++) {
            unsigned char *src_pixel = pSrc + (2*y)*src_step + (2*x)*c;
            unsigned char *dst_pixel = pDst + y*dst_step + x*c;
            for (int k = 0; k < c; k++) {
                dst_pixel[k] = src_pixel[k];  // nearest-neighbor
            }
        }
    }
    return dst;
}

// =====================
// Average filter (ksize should be an odd number)
// =====================
IplImage* avg_filter(IplImage *src, int ksize) {
    int w = src->width;
    int h = src->height;
    int c = src->nChannels;

    IplImage *dst = cvCreateImage(cvSize(w, h), src->depth, c);

    unsigned char *pSrc = (unsigned char*) src->imageData;
    unsigned char *pDst = (unsigned char*) dst->imageData;

    int src_step = src->widthStep;
    int dst_step = dst->widthStep;

    int half = ksize / 2;  // offset from center
    int denom = ksize * ksize;

    for (int y = 0; y < h; y++) {
        for (int x = 0; x < w; x++) {
            for (int k = 0; k < c; k++) {
                int sum = 0;

                // iterate over kernel window
                for (int dy = -half; dy <= half; dy++) {
                    for (int dx = -half; dx <= half; dx++) {
                        int yy = y + dy;
                        int xx = x + dx;

                        if (yy >= 0 && yy < h && xx >= 0 && xx < w) {
                            unsigned char *src_pixel = pSrc + yy*src_step + xx*c;
                            sum += src_pixel[k];
                        }
                        // else: outside → treated as 0
                    }
                }

                unsigned char *dst_pixel = pDst + y*dst_step + x*c;
                dst_pixel[k] = sum / denom;
            }
        }
    }
    return dst;
}

// =====================
// Main test
// =====================
int main() {
    CvCapture *cap = cvCaptureFromCAM(0);
    if (!cap) {
        fprintf(stderr, "Error: Cannot open webcam\n");
        return -1;
    }

    cvNamedWindow("Original", CV_WINDOW_AUTOSIZE);
    cvNamedWindow("Resized", CV_WINDOW_AUTOSIZE);
    cvNamedWindow("Filtered", CV_WINDOW_AUTOSIZE);

    while (1) {
        IplImage *frame = cvQueryFrame(cap);
        if (!frame) break;

        IplImage *half = resize_half(frame);
        IplImage *filtered = avg_filter(frame, 5);

        cvShowImage("Original", frame);
        cvShowImage("Resized", half);
        cvShowImage("Filtered", filtered);

        char c = cvWaitKey(30);
        if (c == 27) break;

        cvReleaseImage(&half);
        cvReleaseImage(&filtered);
    }

    cvReleaseCapture(&cap);
    cvDestroyAllWindows();
    return 0;
}
